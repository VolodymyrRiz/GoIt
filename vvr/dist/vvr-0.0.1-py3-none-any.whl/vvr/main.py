def greeting(greet):
    return
