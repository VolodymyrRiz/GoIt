def greeting():
    print ('HELLOW')
